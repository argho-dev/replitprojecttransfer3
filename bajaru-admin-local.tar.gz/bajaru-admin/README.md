# Bajaru Admin Panel

A clean, modern grocery admin dashboard built with React + Vite + Tailwind CSS.

## Features

- **Dashboard** — Stats overview, revenue chart, low-stock alerts
- **Products** — Card grid with search, inline Edit modal (name, price, stock, image)
- **Procurement** — Add new supply orders, mark orders as received

## Tech Stack

- React 19 + TypeScript
- Vite 6
- Tailwind CSS v4
- Shadcn UI components (Radix UI primitives)
- Recharts (dashboard chart)
- Framer Motion (page transitions)
- Wouter (routing)
- TanStack React Query

## Getting Started

### 1. Install dependencies

```bash
npm install
```

### 2. Run the dev server

```bash
npm run dev
```

App will open at **http://localhost:5173**

### 3. Build for production

```bash
npm run build
```

Built files go to the `dist/` folder.

### 4. Preview the production build

```bash
npm run preview
```

## Project Structure

```
bajaru-admin/
├── index.html
├── vite.config.ts
├── tsconfig.json
├── package.json
├── .env.example
└── src/
    ├── main.tsx           # Entry point
    ├── index.css          # Global styles + Tailwind theme (green palette)
    ├── App.tsx            # Root app with routing
    ├── lib/
    │   ├── utils.ts       # cn() helper
    │   └── store.tsx      # Global state (products, procurement) via React Context
    ├── components/
    │   ├── layout/
    │   │   ├── AppLayout.tsx   # Main layout wrapper
    │   │   ├── Sidebar.tsx     # Left navigation
    │   │   └── Header.tsx      # Top header bar
    │   └── ui/                 # Shadcn UI components (Button, Card, Dialog, etc.)
    └── pages/
        ├── dashboard.tsx
        ├── products.tsx
        └── procurement.tsx
```

## Connecting Your Backend

All data is currently in `src/lib/store.tsx` as dummy data.
To connect your Node.js + MongoDB backend:

1. Create a `.env` file (copy from `.env.example`)
2. Add your API URL: `VITE_API_BASE_URL=http://localhost:3000/api`
3. Replace the dummy data in `store.tsx` with API calls using TanStack Query hooks

## Environment Variables

See `.env.example` — no variables required to run locally.
